import os
import pygame
from random import randint
import random

def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    return image

f = open("high.txt", mode="r")
highscore = int(f.readline())
f.close()

pygame.init()
size = width, height = 800, 500
screen = pygame.display.set_mode(size)
screen.fill(pygame.Color('White'))
running = True

img = []
img.append(load_image('1.png'))
img.append(load_image('2.png'))

standart = load_image("0.png")

img2 = []
img2.append(load_image('3.png'))
img2.append(load_image('4.png'))


all_sprites = pygame.sprite.Group()
dino = pygame.sprite.Sprite()
dino.image = standart
dino.rect = dino.image.get_rect()
all_sprites.add(dino)

dino.rect.x = 50
dino.rect.y = 400

dy = ''

cactus = pygame.sprite.Sprite()
cactus.image = load_image('cactus.png')
cactus.rect = cactus.image.get_rect()
all_sprites.add(cactus)

img3 = []
img3.append(load_image('b1.png'))
img3.append(load_image('b2.png'))


cactus.rect.x = 1200
cactus.rect.y = 400


#f1 = pygame.font.Font(None, 36)
#text1 = f1.render('No Internet Connection', 1, (100, 100, 100))
#pygame.display.update()

my_font = pygame.font.Font(None, 24) 




j = 0
i = 0
game_on = False
n = 2
down = False

def check():
    global game_on, cactus, dino, dy, n, i, j, score
    if dino.rect.colliderect(cactus.rect):
        cactus.rect.x = 1200
        cactus.rect.y = 400
        dy = ''
        dino.rect.x = 50
        dino.rect.y = 400
        j = 0
        i = 0
        n = 2
        game_on = False
        
        return True
        

score = 0
flying = False
k = 0
pygame.display.flip()
while running:
    if game_on == True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False         
        
        ############################################################CACTUS####################################################################
        if i % n == 0:
            cactus.rect.x -= 1
            if (i % 50 == 0) and flying:
                cactus.image = img3[k % 2]
                k += 1
                
        if cactus.rect.x <= -10:
            if randint(0, 1) == 1:
                cactus.image = img3[k % 2]
                flying = True
                cactus.rect = cactus.image.get_rect()
                cactus.rect.y = random.choice([400, 325, 250])
            else:
                flying = False
                cactus.image = load_image('cactus.png')
                cactus.rect.y = 400
            cactus.rect.x = randint(800, 1200)

        
        #############################################################DINO########################################################################
        if i % 10 == 0:
            if dy != '':
                dino.rect.y += dy
                dy += 1
                if dy > 25:
                    dy = ''
                dino.image = standart
            elif i % 50 == 0:
                if not down:
                    dino.image = img[j % 2]
                    j += 1
                else:
                    dino.image = img2[j % 2]
                    j += 1
        screen.fill((255, 255, 255))
        score = i // 50
        score_text = my_font.render('Score: ' + str(score), 0, (100, 100, 100))
        h_text = my_font.render('Previous hi-score: ' + str(highscore), 0, (100, 100, 100))
        screen.blit(score_text, (700, 10))
        screen.blit(h_text, (630, 30))
        all_sprites.draw(screen)
        pygame.display.flip()
        
        i += 1
        pressed_keys = pygame.key.get_pressed()
        if pressed_keys[pygame.K_UP]:
            if dy == '':
                dy = -25
            else:
                pass
        if pressed_keys[pygame.K_DOWN]:
            if (not down) and dy == '':
                dino.img = img2[j % 2]
                pygame.display.flip()
                dino.rect = dino.image.get_rect()
                dino.rect.y = 430
                dino.rect.x = 40
                down = True
                pygame.display.flip()
        else:
            if down and dy == '':
                dino.image = img[j % 2]
                dino.rect = dino.image.get_rect()
                dino.rect.y = 400
                dino.rect.x = 50
                down = False
                pygame.display.flip()
            #пригиб
        if pressed_keys[pygame.K_RIGHT]:
            dino.rect.x += 1
        if pressed_keys[pygame.K_LEFT]:
            dino.rect.x -= 1

    else:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        pressed_keys = pygame.key.get_pressed()
        if pressed_keys[pygame.K_SPACE]:
            #print('oh')
            flying = False
            cactus.rect.x = 1200
            cactus.rect.y = 400
            dy = ''
            dino.rect.x = 50
            dino.rect.y = 400
            j = 0
            i = 0
            n = 2
            f = open("high.txt", mode="r")
            highscore = int(f.readline())
            f.close()
            if score >= highscore:
                #print('OOOOOHHHHH YEAAAAAAAa')
                f = open("high.txt", 'w')
                f.write(str(score))
                #print(score)
                f.close
            pygame.display.flip()
            score = 0
            f = open("high.txt", mode="r")
            highscore = int(f.readline())
            f.close()

            game_on = True
    
     
    #проверка
        
    if check():
        dino.image = load_image('dead.png')

pygame.quit()
